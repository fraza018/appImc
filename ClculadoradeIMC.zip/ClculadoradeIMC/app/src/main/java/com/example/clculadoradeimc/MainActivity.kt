package com.example.calculadoradeimc

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.clculadoradeimc.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Referências para os campos de entrada e elementos da interface
        val etPeso = findViewById<EditText>(R.id.etPeso)
        val etAltura = findViewById<EditText>(R.id.etAltura)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val tvResultado = findViewById<TextView>(R.id.tvResultado)

        // Lógica para o cálculo do IMC ao clicar no botão
        btnCalcular.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                // Obter valores de peso e altura
                val peso = etPeso.text.toString().toDoubleOrNull()
                val altura = etAltura.text.toString().toDoubleOrNull()

                // Verificar se os valores são válidos
                if (peso != null && altura != null && peso > 0 && altura > 0) {
                    // Calcular o IMC
                    val imc = peso / (altura * altura)

                    // Exibir o IMC e a classificação
                    tvResultado.text = "Seu IMC é: %.2f".format(imc)

                    // Classificar o IMC
                    when {
                        imc < 18.5 -> tvResultado.append("\nClassificação: Abaixo do peso")
                        imc in 18.5..24.9 -> tvResultado.append("\nClassificação: Peso normal")
                        imc in 25.0..29.9 -> tvResultado.append("\nClassificação: Sobrepeso")
                        imc in 30.0..39.9 -> tvResultado.append("\nClassificação: Obesidade")
                        else -> tvResultado.append("\nClassificação: Obesidade grave")
                    }
                } else {
                    // Exibir mensagem de erro se algum valor for inválido
                    tvResultado.text = "Por favor, insira valores válidos para peso e altura."
                }
            }
        })
    }
}
